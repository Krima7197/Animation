//
//  ViewController.swift
//  Animation
//
//  Created by TOPS on 8/31/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,CAAnimationDelegate {
    var frm:CGRect? = nil
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        frm=viewCon.frame
    }
    @IBOutlet weak var viewCon: UIView!
    @IBAction func btnAction(_ sender: Any)
    {   UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(1.5)
        UIView.setAnimationDelegate(self)
        viewCon.frame=CGRect(x: 250, y: 300, width: 100, height: 100)
        UIView.commitAnimations()
    }
    func animationDidStop(_ anim: CAAnimation, finished flag: Bool) {
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(1.5)
        viewCon.frame=frm!
        UIView.commitAnimations()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

